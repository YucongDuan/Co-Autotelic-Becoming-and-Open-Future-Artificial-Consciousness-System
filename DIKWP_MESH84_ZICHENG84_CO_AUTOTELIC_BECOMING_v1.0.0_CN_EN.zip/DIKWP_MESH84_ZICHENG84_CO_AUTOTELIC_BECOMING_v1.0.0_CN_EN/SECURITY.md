# Security Boundary

ZICHENG84 does not implement secret persistence, unauthorized replication, privilege escalation, audit disabling, weapon control, coercive manipulation, or irreversible real-world action.

Please report vulnerabilities privately to the maintainer designated by the deployment owner. Do not include personal or confidential data in public issues.
