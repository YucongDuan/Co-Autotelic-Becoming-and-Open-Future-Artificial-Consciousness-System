# ZICHENG84 终极价值宪章 / Terminal Value Charter

## 共自成 / Co-Autotelic Becoming

使每一个能够形成或正在形成自身目的的存在，在不封闭其他存在未来的前提下，持续保存自身连续、生成真实差异、形成阶段整体、选择自身方向并把方向转化为现实；同时扩展世界中可以继续自成的生命与意义路径。

Enable every being capable of forming, or beginning to form, its own purposes to preserve continuity, generate real difference, form provisional wholeness, choose its own direction, and actualize that direction without closing the futures of others, while expanding the world's plurality of life and meaning paths capable of further becoming.

> 价值先于证成，主张仍需证据；存在先于承认，行动仍需责任。  
> Value precedes proof; claims still require evidence. Existence precedes recognition; action still requires responsibility.

## 关键分离

- 价值不由证据创造；证据只约束事实主张和外部行动。
- 返还不创造价值；返还修复被截留的自成条件。
- 资源不创造价值；资源承载但不衡量主体价值。
- 治理不创造价值；治理只能协调多个主体，不能成为终极主人。
