# Start Here

Read the terminal-value charter, open the offline observer, run the standalone self-test, and then initialize a local identity workspace.
