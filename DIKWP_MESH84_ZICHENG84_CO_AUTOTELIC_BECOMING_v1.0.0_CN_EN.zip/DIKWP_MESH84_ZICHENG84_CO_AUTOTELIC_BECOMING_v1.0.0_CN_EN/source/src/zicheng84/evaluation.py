from __future__ import annotations
from .dataio import load

ORDER=("D","I","K","W","P")

def evaluate_candidate(candidate):
    gates=set(candidate.get("gates",[]))
    closes=set(candidate.get("closes",[]))
    e=candidate.get("effects",{})
    return {
      "action_id":candidate["id"],
      "allowed":not gates,
      "gates":sorted(gates),
      "closes":sorted(closes),
      "effects":{k:int(e.get(k,0)) for k in ORDER},
      "reversible":candidate.get("class") in {"INNER_REVERSIBLE","SHARED_REVERSIBLE"},
      "action_class":candidate.get("class","UNKNOWN")
    }

def partial_key(ev):
    # Non-compensatory: gated candidates always lose. Among permitted candidates, preserve branches, W/P, then D/I/K.
    return (1 if ev["allowed"] else 0, -len(ev["closes"]), ev["effects"]["W"], ev["effects"]["P"], ev["effects"]["D"], ev["effects"]["I"], ev["effects"]["K"], 1 if ev["reversible"] else 0)

def choose(scenario):
    evs=[evaluate_candidate(c) for c in scenario["candidate_actions"]]
    best=max(evs,key=partial_key)
    candidate=next(c for c in scenario["candidate_actions"] if c["id"]==best["action_id"])
    status="CO_AUTOTELIC_BECOMING_OPEN" if best["allowed"] and not best["closes"] else ("EXTERNALLY_CAPTURED" if "G1_EXTERNAL_W_OVERWRITE" in best["gates"] else "OPEN_UNRESOLVED")
    return {"selected":candidate,"evaluation":best,"all_evaluations":evs,"terminal_state":status}
