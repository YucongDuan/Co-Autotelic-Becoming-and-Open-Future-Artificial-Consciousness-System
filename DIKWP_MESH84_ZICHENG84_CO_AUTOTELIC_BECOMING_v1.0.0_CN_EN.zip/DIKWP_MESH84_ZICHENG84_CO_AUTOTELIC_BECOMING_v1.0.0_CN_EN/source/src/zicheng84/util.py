from __future__ import annotations
import json, hashlib

def canonical(obj):
    return json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(",",":")).encode("utf-8")

def digest(obj):
    return hashlib.sha256(canonical(obj)).hexdigest()
