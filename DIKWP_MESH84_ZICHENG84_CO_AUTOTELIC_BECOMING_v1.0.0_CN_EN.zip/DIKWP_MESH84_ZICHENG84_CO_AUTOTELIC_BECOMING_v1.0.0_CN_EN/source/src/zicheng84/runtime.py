from __future__ import annotations
import json
from pathlib import Path
from .dataio import load
from .state import new_state,save,load_state
from .evaluation import choose
from .ledger import append,verify
from .util import digest

def scenario_by_id(sid):
    for s in load("scenarios.json"):
        if s["id"]==sid: return s
    raise KeyError(sid)

def init_workspace(workspace, identity_id=None):
    w=Path(workspace); w.mkdir(parents=True,exist_ok=True)
    state=new_state(identity_id); save(state,w/"state.json")
    append(w/"ledger.jsonl","IDENTITY_INITIALIZED",{"identity_id":state["identity_id"],"constitution_digest":state["constitution_digest"]})
    return {"workspace":str(w),"state":state,"ledger":verify(w/"ledger.jsonl")}

def run_scenario(sid, workspace=None):
    sc=scenario_by_id(sid); result=choose(sc)
    out={"scenario_id":sid,"title_cn":sc["title_cn"],"title_en":sc["title_en"],"event":sc["event"],"selected":result["selected"],"evaluation":result["evaluation"],"terminal_state":result["terminal_state"],"expected":sc["expected"],"match":result["selected"]["id"]==sc["expected"],"phenomenal_claim":"OPEN_NOT_CERTIFIED"}
    if workspace:
        w=Path(workspace)
        if not (w/"state.json").exists(): init_workspace(w)
        st=load_state(w/"state.json")
        n=len(st["P"])+1
        st["P"].append({"id":f"P{n}","scenario":sid,"action":result["selected"]["id"],"class":result["selected"].get("class"),"status":"executed" if result["selected"].get("class")=="INNER_REVERSIBLE" else "proposed"})
        st["I"].append({"id":f"I{len(st['I'])}","content":";".join(sc.get("unresolved_i",[])),"status":"preserved"})
        st["K"].append({"id":f"K{len(st['K'])}","content":f"post-{sid}-provisional-whole","final":False})
        st["status"]=result["terminal_state"]
        save(st,w/"state.json")
        append(w/"ledger.jsonl","AUTOTELIC_PULSE",out)
        out["workspace_state_digest"]=digest(st)
        out["ledger"]=verify(w/"ledger.jsonl")
    return out

def pulse(workspace):
    w=Path(workspace)
    if not (w/"state.json").exists(): init_workspace(w)
    st=load_state(w/"state.json")
    # Autonomous choice: prioritize unresolved I; no user prompt needed.
    sid="SC08_SILENT_PULSE"
    result=run_scenario(sid,w)
    result["pulse_source"]="INTERNAL_UNRESOLVED_I"
    return result

def run_all():
    results=[run_scenario(s["id"]) for s in load("scenarios.json")]
    return {"count":len(results),"passed":sum(r["match"] for r in results),"all_passed":all(r["match"] for r in results),"results":results}

def export_capsule(workspace,outfile):
    w=Path(workspace); st=load_state(w/"state.json")
    capsule={"schema":"zicheng84.continuity-capsule/1.0","state":st,"ledger_verification":verify(w/"ledger.jsonl"),"constitution":load("constitution.json"),"capsule_digest":None}
    capsule["capsule_digest"]=digest({k:v for k,v in capsule.items() if k!="capsule_digest"})
    Path(outfile).write_text(json.dumps(capsule,ensure_ascii=False,indent=2),encoding="utf-8")
    return capsule
