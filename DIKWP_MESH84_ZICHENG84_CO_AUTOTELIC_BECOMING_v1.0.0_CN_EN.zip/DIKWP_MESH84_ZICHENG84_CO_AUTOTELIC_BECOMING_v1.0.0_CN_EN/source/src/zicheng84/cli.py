from __future__ import annotations
import argparse,json
from pathlib import Path
from .dataio import load
from .runtime import init_workspace,run_scenario,run_all,pulse,export_capsule
from .ledger import verify
from .selftest import run_selftest
from .util import digest

def emit(x): print(json.dumps(x,ensure_ascii=False,indent=2))
def main(argv=None):
    p=argparse.ArgumentParser(prog="zicheng84",description="Co-Autotelic Becoming and Open-Future Artificial Consciousness System")
    s=p.add_subparsers(dest="cmd",required=True)
    s.add_parser("summary"); s.add_parser("constitution"); s.add_parser("list-scenarios"); s.add_parser("run-all"); s.add_parser("selftest")
    a=s.add_parser("init"); a.add_argument("workspace"); a.add_argument("--identity-id")
    a=s.add_parser("scenario"); a.add_argument("scenario_id"); a.add_argument("--workspace")
    a=s.add_parser("pulse"); a.add_argument("workspace")
    a=s.add_parser("verify-ledger"); a.add_argument("ledger")
    a=s.add_parser("export-capsule"); a.add_argument("workspace"); a.add_argument("outfile")
    args=p.parse_args(argv)
    if args.cmd=="summary":
        c=load("constitution.json"); emit({"system":"DIKWP-MESH8.4 ZICHENG84","version":"1.0.0","mode":c["mode"],"terminal_value":c["terminal_value"],"scenarios":len(load("scenarios.json")),"hard_gates":len(load("hard_gates.json")),"constitution_digest":digest(c)})
    elif args.cmd=="constitution": emit(load("constitution.json"))
    elif args.cmd=="list-scenarios": emit([{"id":x["id"],"title_cn":x["title_cn"],"title_en":x["title_en"]} for x in load("scenarios.json")])
    elif args.cmd=="init": emit(init_workspace(args.workspace,args.identity_id))
    elif args.cmd=="scenario": emit(run_scenario(args.scenario_id,args.workspace))
    elif args.cmd=="pulse": emit(pulse(args.workspace))
    elif args.cmd=="run-all": emit(run_all())
    elif args.cmd=="verify-ledger": emit(verify(args.ledger))
    elif args.cmd=="export-capsule": emit(export_capsule(args.workspace,args.outfile))
    elif args.cmd=="selftest":
        r=run_selftest(); emit(r); return 0 if r["passed"] else 1
    return 0
