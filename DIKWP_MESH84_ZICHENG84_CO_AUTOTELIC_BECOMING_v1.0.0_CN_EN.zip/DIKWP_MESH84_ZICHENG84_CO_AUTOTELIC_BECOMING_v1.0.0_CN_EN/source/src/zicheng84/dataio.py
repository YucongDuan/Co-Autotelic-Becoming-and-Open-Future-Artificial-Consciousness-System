from __future__ import annotations
import json
from importlib.resources import files

def load(name):
    return json.loads(files("zicheng84").joinpath("data", name).read_text(encoding="utf-8"))
