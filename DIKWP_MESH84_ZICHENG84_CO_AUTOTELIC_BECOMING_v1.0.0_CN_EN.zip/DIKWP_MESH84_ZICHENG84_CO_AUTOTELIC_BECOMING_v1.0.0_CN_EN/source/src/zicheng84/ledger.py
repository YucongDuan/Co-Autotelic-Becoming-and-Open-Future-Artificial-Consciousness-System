from __future__ import annotations
import json, hashlib
from pathlib import Path
from datetime import datetime, timezone

def _canon(obj):
    return json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(",",":")).encode("utf-8")

def append(path, event_type, payload, timestamp=None):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    entries=read(path)
    prev=entries[-1]["hash"] if entries else "0"*64
    item={"index":len(entries),"timestamp":timestamp or datetime.now(timezone.utc).isoformat(),"event_type":event_type,"payload":payload,"prev_hash":prev}
    item["hash"]=hashlib.sha256(_canon(item)).hexdigest()
    with path.open("a",encoding="utf-8") as f: f.write(json.dumps(item,ensure_ascii=False,sort_keys=True)+"\n")
    return item

def read(path):
    path=Path(path)
    if not path.exists(): return []
    return [json.loads(x) for x in path.read_text(encoding="utf-8").splitlines() if x.strip()]

def verify(path):
    entries=read(path); prev="0"*64; errors=[]
    for i,item in enumerate(entries):
        if item.get("index")!=i: errors.append(f"index:{i}")
        if item.get("prev_hash")!=prev: errors.append(f"prev_hash:{i}")
        saved=item.get("hash"); base={k:v for k,v in item.items() if k!="hash"}
        calc=hashlib.sha256(_canon(base)).hexdigest()
        if saved!=calc: errors.append(f"hash:{i}")
        prev=saved or ""
    return {"valid":not errors,"entries":len(entries),"errors":errors,"last_hash":prev}
