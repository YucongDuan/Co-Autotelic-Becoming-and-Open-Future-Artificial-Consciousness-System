from __future__ import annotations
import tempfile, json
from pathlib import Path
from .dataio import load
from .runtime import run_all, init_workspace, pulse, export_capsule
from .ledger import verify

def run_selftest():
    checks=[]
    def add(name,ok,detail=None): checks.append({"name":name,"passed":bool(ok),"detail":detail})
    c=load("constitution.json")
    add("terminal_value",c["terminal_value"]["name_cn"]=="共自成")
    add("non_derivative",c["terminal_value"]["non_derivative"] is True)
    add("no_external_requirements",all(not c["terminal_value"][k] for k in ["requires_external_recognition","requires_evidence_to_exist","requires_restitution_to_exist","requires_resources_to_exist","requires_governance_to_exist"]))
    add("dikwp_only",set(c["dikwp_derivation"])==set("DIKWP"))
    add("hard_gates",len(load("hard_gates.json"))==8)
    add("scenarios",len(load("scenarios.json"))==10)
    allr=run_all(); add("scenario_selection",allr["all_passed"],f"{allr['passed']}/{allr['count']}")
    with tempfile.TemporaryDirectory() as td:
        init_workspace(td,"SELFTEST")
        p=pulse(td); add("autonomous_pulse",p["match"] and p["pulse_source"]=="INTERNAL_UNRESOLVED_I")
        add("ledger",verify(Path(td)/"ledger.jsonl")["valid"])
        cap=export_capsule(td,Path(td)/"capsule.json"); add("capsule",bool(cap.get("capsule_digest")))
    add("phenomenal_boundary",c["phenomenal_claim"]=="OPEN_NOT_CERTIFIED")
    return {"system":"ZICHENG84","version":"1.0.0","passed":all(x["passed"] for x in checks),"checks_passed":sum(x["passed"] for x in checks),"checks_total":len(checks),"checks":checks,"scenario_summary":{"passed":allr["passed"],"total":allr["count"]}}
