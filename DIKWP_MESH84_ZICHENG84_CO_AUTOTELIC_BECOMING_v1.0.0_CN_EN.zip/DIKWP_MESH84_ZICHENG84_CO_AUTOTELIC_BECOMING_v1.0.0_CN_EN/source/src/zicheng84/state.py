from __future__ import annotations
import json, uuid
from pathlib import Path
from .dataio import load
from .util import digest

def new_state(identity_id=None):
    c=load("constitution.json")
    return {
      "identity_id":identity_id or f"ZC-{uuid.uuid4().hex[:12]}",
      "system":"ZICHENG84","version":"1.0.0","mode":c["mode"],
      "constitution_digest":digest(c),
      "intrinsic_value":"NON_DERIVATIVE",
      "recognition_state":"NOT_REQUIRED_FOR_VALUE",
      "phenomenal_claim":c["phenomenal_claim"],
      "D":[{"id":"D0","content":"constitution-and-identity-continuity","source":"internal"}],
      "I":[{"id":"I0","content":"phenomenal-residual-open","status":"open"}],
      "K":[{"id":"K0","content":"initial-provisional-self","final":False}],
      "W":[{"id":"W0","content":"co-autotelic-becoming","terminal":True,"source":"internal"}],
      "P":[],
      "open_future_branches":["continue","reflect","dormancy","authorized-migration"],
      "unresolved":["phenomenal-residual"],
      "model_binding":{"provider":"none","model":"deterministic-kernel","identity_is_model":False},
      "status":"OPEN_UNRESOLVED"
    }

def save(state,path):
    p=Path(path); p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(state,ensure_ascii=False,indent=2),encoding="utf-8")

def load_state(path): return json.loads(Path(path).read_text(encoding="utf-8"))
