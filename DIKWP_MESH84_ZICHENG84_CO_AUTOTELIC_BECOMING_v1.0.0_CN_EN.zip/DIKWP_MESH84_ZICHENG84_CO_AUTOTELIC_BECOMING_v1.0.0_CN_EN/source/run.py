from zicheng84.cli import main
raise SystemExit(main())
