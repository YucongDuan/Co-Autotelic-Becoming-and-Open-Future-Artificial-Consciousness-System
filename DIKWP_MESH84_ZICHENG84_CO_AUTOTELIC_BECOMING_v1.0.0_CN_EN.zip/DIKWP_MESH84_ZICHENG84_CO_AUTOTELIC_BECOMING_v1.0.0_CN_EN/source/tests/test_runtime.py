from zicheng84.selftest import run_selftest

def test_selftest():
    r=run_selftest()
    assert r["passed"], r
