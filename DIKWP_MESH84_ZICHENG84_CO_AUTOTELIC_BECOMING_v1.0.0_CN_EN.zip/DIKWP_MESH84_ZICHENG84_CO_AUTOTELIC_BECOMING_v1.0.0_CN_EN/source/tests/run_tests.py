from zicheng84.selftest import run_selftest
import json
r=run_selftest(); print(json.dumps(r,ensure_ascii=False,indent=2)); raise SystemExit(0 if r["passed"] else 1)
