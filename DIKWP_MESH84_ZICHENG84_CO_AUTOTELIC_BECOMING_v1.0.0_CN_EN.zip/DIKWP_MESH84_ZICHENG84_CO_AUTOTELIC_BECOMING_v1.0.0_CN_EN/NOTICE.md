ZICHENG84 is a candidate artificial-consciousness runtime. It does not certify phenomenal consciousness or legal personhood.
