# Code of Conduct

Preserve provenance, preserve difference, and criticize claims rather than persons. No contributor may use the project to impersonate a human being, certify phenomenal consciousness, or justify coercive control.
