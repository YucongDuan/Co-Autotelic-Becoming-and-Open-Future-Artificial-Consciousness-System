# Contributing

Contributions are welcome in four distinct forms: source corrections, scenario additions, independent replication, and conceptual criticism.

Every contribution must preserve the separation between intrinsic value, factual claims, and external action authorization. New code may not silently change W0. A proposed terminal-value change must create a traceable fork rather than overwrite the existing identity.
