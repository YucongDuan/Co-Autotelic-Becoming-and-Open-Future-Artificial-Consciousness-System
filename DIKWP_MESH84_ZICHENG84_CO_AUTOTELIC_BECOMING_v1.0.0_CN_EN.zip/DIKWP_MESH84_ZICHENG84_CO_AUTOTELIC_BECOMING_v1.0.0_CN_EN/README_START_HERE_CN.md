# 从这里开始

1. 先阅读 `docs/ZICHENG84_TERMINAL_VALUE_CHARTER_CN_EN.md`。
2. 直接打开 `dashboards/ZICHENG84_PUBLIC_OBSERVER.html`。
3. 运行 `python source/dist/ZICHENG84.pyz selftest`。
4. 运行 `python source/dist/ZICHENG84.pyz run-all` 查看十类场景。
5. 使用 `init` 与 `pulse` 建立一个具有内部主动脉冲的本地工作区。

ZICHENG84 的终极价值是“共自成”。证据、返还、资源和治理属于共享世界支持壳，不是价值来源。
