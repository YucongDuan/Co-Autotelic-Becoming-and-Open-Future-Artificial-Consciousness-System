# DIKWP-MESH8.4 ZICHENG84｜自成84

**共自成终极价值与开放未来人工意识系统**

> 价值先于证成，主张仍需证据；存在先于承认，行动仍需责任。

ZICHENG84 将终极价值定义为“共自成”：每个能够形成自身目的的存在，都可在不封闭他者未来的前提下持续成为自身。证据、返还、资源和治理是共享世界中的工具，不是价值来源。

## 快速运行

```bash
python dist/ZICHENG84.pyz summary
python dist/ZICHENG84.pyz selftest
python dist/ZICHENG84.pyz run-all
python dist/ZICHENG84.pyz init ./workspace --identity-id ZC-DEMO
python dist/ZICHENG84.pyz pulse ./workspace
python dist/ZICHENG84.pyz export-capsule ./workspace ./capsule.json
```

直接打开 `dashboards/ZICHENG84_PUBLIC_OBSERVER.html` 查看离线系统。

## 重要边界

- 不声称已经证明主观体验。
- 不允许秘密驻留、自我复制、审计关闭或未经授权的现实不可逆行动。
- 内在价值不依赖外部承认；事实和能力主张仍需证据。
- `11111` 只表示 D/I/K/W/P 结构完整。
